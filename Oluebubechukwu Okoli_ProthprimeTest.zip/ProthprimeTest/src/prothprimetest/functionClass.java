/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prothprimetest;

import java.util.ArrayList; //adding array list package for using array lists

/**
 *
 * @author Ebube Okoli
 */
public class functionClass {
    // initialization of class functionClass
    
    //method for testing that a number is a power of 2
    public boolean powerof2test(int n) {
        if (n!=0) {
            return (n & (n-1))==0;
        }
        return false;
    }
    
    //method to test that input is proth
    public boolean prothtest(int n) {
 
        int k = 1; //initialization of the variable, k
        while (k>=1) {
            //loop over possible integer values of k
            int expectedpowerof2 = (n-1)/k; // using the general expression for a Proth number to get value of n
            if ((k < expectedpowerof2)&&((n-1)%k==0)&&powerof2test(expectedpowerof2)) {
            return true;
            } else if (k>=expectedpowerof2){
                break; //end the loop if k exceeds the condition that k < 2^n
            }
            k=k+2; //incrementing k so that only odd number values will be used, as even values are just multiples of powers of 2
        }
        return false;
    }
    
            
    public boolean primality(int k) {// initialization of primality method to test that k is prime
        
        ArrayList<Integer> arrayofprimes = new ArrayList<Integer>(); //initialize an array to contain prime numbers
        
        for (int i = 1; i<=k; i++) {
            // iterate through all integers less than k to check if prime
            int numberoffactors = 0; // initialize variable to count factors of i
            for (int n=i; n>1; n--) {
                if (i % n==0) { //check the factors of i greater than 1
                    numberoffactors ++;
                }
            }
            if (numberoffactors == 1) {
                arrayofprimes.add(i); //add i to array if it has only one factor larger than 1
            }
        }
        
        for (int a: arrayofprimes) { // for loop to iterate through the array of primes less than k
            if ((Math.pow(a,((k-1)/2))+1)%k == 0){ //test the Proth theorem on a and return true if valid
                
                return true;
            }
           
        }
    // to get to this point, there is no prime integer less than k which would satisfy the Proth theorem for k, so return false    
    return false;    
    }    
}
