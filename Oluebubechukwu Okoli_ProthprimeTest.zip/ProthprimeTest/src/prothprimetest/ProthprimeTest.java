/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prothprimetest;
import java.util.Scanner;
/**
 *
 * @author Ebube Okoli
 */

//main driver class initialization
public class ProthprimeTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);//create an object instance of Scanner Class
        
        System.out.println("Please enter a valid proth number to test: ");
        int proth_input = input.nextInt();//collect integer proth number input from user
        
        functionClass value = new functionClass();// create a new object instance of the class functionClass
        
        boolean isproth = value.prothtest(proth_input); //test that the input number is proth
        
        if (isproth) {
            boolean primetest = value.primality(proth_input); // run the primality method on its class object and assign result to variable primetest
            if (primetest){
                System.out.println(proth_input + " is prime.");
            }
            else {
                System.out.println(proth_input + " is not prime.");
            }
        }
        else {
            System.out.println("This is not a proth number.");
            main(null);//re-run the driver class to start the progrem again
        }
    } 
}
