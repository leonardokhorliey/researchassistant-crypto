/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prothprimetest;
import java.util.Scanner;
/**
 *
 * @author Ebube Okoli
 */
public class ProthprimeTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);//create an object instance of Scanner Class
        
        System.out.println("Please enter the proth number to test: ");
        int proth_input = input.nextInt();//collect integer proth number input from user
        
        functionClass value = new functionClass();// create a new object instance of the class functionClass
        boolean primetest = value.primality(proth_input); // run the primality method on its class object and assign result to variable primetest
        
        if (primetest){
            System.out.println(proth_input + " is prime.");
        }
    }
    
}
