/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prothprimetest;

/**
 *
 * @author Ebube Okoli
 */
public class functionClass {
    // initialization of class functionClass
    
    public boolean primality(int n) {// initialization of primality method to return boolean output
        int a = 1;// initializing the test variable, a
        while (a >= 1){
            if ((Math.pow(a,((n-1)/2)))%n + 1 == n){
                // testing the Proth theorem condition on the variable, n
                break;
            }
            a++;
            
        }
        return true;// to return boolean value of true at the end of method body computations
    }
}
